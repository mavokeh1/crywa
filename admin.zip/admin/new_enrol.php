<?php

echo $_REQUEST['id'].'.jpg';
$name=$_REQUEST['id'].'.jpg';
$sql="insert into faces ('dep','id','name') values('','','$name')";
