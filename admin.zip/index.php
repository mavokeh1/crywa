<!DOCTYPE html>
<html>
   <head>
    <title>Face-Recognition-Application</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="asset/css/style.css">
      <link rel="stylesheet" type="text/css" href="asset/css/style1.css">
<!-- Data Table JS============================================ -->
<link rel="stylesheet" href="css/jquery.dataTables.min.css">
      <style>
         .box {
         background: transparent;
         position: relative;
         width:auto;
         }
         .frame {
         position: absolute;
         top: 55%;
         left: 50%;
         transform: translate(-50%, -50%);
         border: 3px solid #e9e9e9;
         z-index: 3;
         }
         .camera{
         width:500px;
         border-radius:10px;
         border:10px solid;
         border-style: outset;
         box-shadow: 0px 1px 2px #eee, 0px 2px 2px #e9e9e9, 0px 3px 2px #ccc, 0px 4px 2px #c9c9c9, 0px 5px 2px #bbb, 0px 6px 2px #b9b9b9, 0px 7px 2px #999, 0px 7px 2px rgba(0, 0, 0, 0.5), 0px 7px 2px rgba(0, 0, 0, 0.1), 0px 7px 2px rgba(0, 0, 0, 0.73), 0px 3px 5px rgba(0, 0, 0, 0.3), 0px 5px 10px rgba(0, 0, 0, 0.37), 0px 10px 10px rgba(0, 0, 0, 0.1), 0px 20px 20px rgba(0, 0, 0, 0.1);
         }
         table, td, th {  
         border: 1px solid #ddd;
         text-align: left;
         }

         table {
         border-collapse: collapse;
         width: 100%;
         }
         thead{
            background-color:rgb(0,197,146);
         }
         th, td {
         padding: 3px;
         font-size:18px;
         color:#001200;
         }
      </style>
      <script src="asset/js/modernizr.js"></script>
      <script src="asset/js/vue.min.js"></script>
   </head>
   <body>
      <div class="top-container">
         
      <div class="data">
         </div>
         <div class="data">
         </div>
         <div class="data">
         </div>
         <div class="data">
         </div>
         <div class="data">
            <a href="login.php"><i class="fa fa-user"></i> Login</a>
         </div>
      </div>
      <div class="time-container">
         <div class="display-time">
            <h1>Face Recognition Attendance System</h1>
            <h6 style="color:#000">
               <?php
                  $Today=date('y:m:d');
                  $new=date('l, F d, Y',strtotime($Today));
                  echo $new; ?>
            </h6><br>
            <table id="data-table-basic" class="table table-border">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>TimeIn</th>
                                        <th>TimeOut</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Jennifer Wambui</td>
                                        <td>08:00 AM</td>
                                        <td>05:00 PM</td>
                                    </tr>
                                    <tr>
                                        <td>Vicente Owino</td>
                                        <td>08:10 AM</td>
                                        <td>05:06 PM</td>
                                    </tr>
                                    <tr>
                                        <td>Karen juma</td>
                                        <td>08:15 AM</td>
                                        <td>05:12 PM</td>
                                    </tr>
                                    <tr>
                                        <td>Shelly kim</td>
                                        <td>07:58 AM</td>
                                        <td>04:56 PM</td>
                                    </tr>
                                </tbody>
                            </table>
         </div>
      </div>
      <div class="container">
         <div class="img">
            
         </div>

         <div class="login-content">
            
            <div id="app" class="row box">
               <div class="col-md-4 col-md-offset-4">
                  <ul style="list-style:none;display:none">
                     <li v-if="cameras.length === 0" class="empty">No cameras found</li>
                     <li v-for="camera in cameras">
                        <span v-if="camera.id == activeCameraId" :title="formatName(camera.name)"
                           class="active"><input type="radio" class="align-middle mr-1" checked> {{
                        formatName(camera.name) }}</span>
                        <span v-if="camera.id != activeCameraId" :title="formatName(camera.name)">
                        <a @click.stop="selectCamera(camera)"> <input type="radio" class="align-middle mr-1">@{{
                        formatName(camera.name) }}</a>
                        </span>
                     </li>
                  </ul>
                  <div class="clearfix"></div>
                  <!-- form scan -->
                  <form action="" method="POST" id="myForm">
                     <input style="display:none" type="text" name="qrcode" id="code" autofocus>
                  </form>
               </div>
               <div class="col-xs-12 preview-container">
                  <figure class="box frame" style="width:200px;height:200px"> </figure>
                  <video id="preview" class="camera" autofocus></video>
               </div>
            </div>
         </div>
      </div>
      </div>
      </div>
      </script>
      
      <script src="asset/js/instascan.min.js"></script>
      <script src="asset/js/main.js"></script>
<!-- Data Table JS============================================ -->
<script src="js/data-table/jquery.dataTables.min.js"></script>
<script src="js/data-table/data-table-act.js"></script>
   </body>
</html>